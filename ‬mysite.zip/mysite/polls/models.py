from django.db import models

class Student(models.Model):
    username = models.charField(max_Length=100)
    email = models.EmailFeild(unique=True)
    password = models.charFeild(max_Length=100)

    def __str__(self):
        return self.username

# Create your models here.
