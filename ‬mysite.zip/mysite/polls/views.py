from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *

def home(request):
    return render(request,"home.html")

from django.shortcuts import render, redirect
from .models import Student

def register(request):
    if request.method =='POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')


        if Student.objects.filter(email=email).exits():
            messages.error(request, 'Email already registered.')
            return redirect('register')

        Student.objects.create(username=username, email=email, password=password)
        messages.success(request, 'Registration successfull please log in.')
        return redirect('login')

    return render(request, 'register.html')  

def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            student = Student.objects.get(email=email)
            if student.password == password:

                request.session['student_id'] = student.id 
                request.session['username'] = student.username
                message.success(request, f'welcome, {student.username}!')
                return redirect('dashboard')
            else:
                message.error(request, 'Invalid password.')
        except Student.DoesNotExit:
            message.error(request, 'email not found.')                   
    return render(request, 'login.html') 
def dashboard(request):
    student_id=request.session.get('student_id') 
    if not student_id:
        messages.error(request,'please login first')
        return redirect('login')

        student=Student.objects.get(id=student_id)
        return render(request,  'dashboard.html', {'student':student})

    def logout(request):
        reqeust.session.flush()
        messages.success(request, 'Logged out Successfully.')
        return redirect('home')
             
